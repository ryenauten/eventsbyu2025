"use client"

import { useState, useEffect } from "react"
import { Calendar, Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { useCalendar } from "@/hooks/use-calendar"

interface SaveEventButtonProps {
  eventId: string
}

export function SaveEventButton({ eventId }: SaveEventButtonProps) {
  const { toast } = useToast()
  const { savedEvents, saveEvent, removeEvent } = useCalendar()
  const [isSaved, setIsSaved] = useState(false)

  useEffect(() => {
    setIsSaved(savedEvents.includes(eventId))
  }, [savedEvents, eventId])

  const handleToggleSave = () => {
    if (isSaved) {
      removeEvent(eventId)
      toast({
        title: "Event removed",
        description: "Event has been removed from your calendar",
        variant: "default",
      })
    } else {
      saveEvent(eventId)
      toast({
        title: "Event saved",
        description: "Event has been added to your calendar",
        variant: "default",
      })
    }
  }

  return (
    <Button
      onClick={handleToggleSave}
      className={isSaved ? "bg-green-600 hover:bg-green-700" : "bg-byu-navy hover:bg-byu-royal"}
    >
      {isSaved ? (
        <>
          <Check className="mr-2 h-4 w-4" />
          Added to Calendar
        </>
      ) : (
        <>
          <Calendar className="mr-2 h-4 w-4" />
          Add to My Calendar
        </>
      )}
    </Button>
  )
}

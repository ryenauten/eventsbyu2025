"use client"

import Link from "next/link"
import { Calendar, Home, Menu } from "lucide-react"
import { useState } from "react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useMobile } from "@/hooks/use-mobile"

export function Navbar() {
  const isMobile = useMobile()
  const [open, setOpen] = useState(false)

  const navLinks = [
    { name: "Home", href: "/", icon: <Home className="mr-2 h-4 w-4" /> },
    { name: "Sports", href: "/events/sports", icon: null },
    { name: "Underclassman", href: "/events/underclassman", icon: null },
    { name: "Senior", href: "/events/senior", icon: null },
    { name: "Clubs", href: "/events/club", icon: null },
    { name: "My Calendar", href: "/calendar", icon: <Calendar className="mr-2 h-4 w-4" /> },
  ]

  return (
    <nav className="sticky top-0 z-10 border-b bg-white">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link href="/" className="flex items-center">
          <span className="text-xl font-bold text-blue-900">BYU Events</span>
        </Link>

        {isMobile ? (
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col gap-4 py-4">
                {navLinks.map((link) => (
                  <Link
                    key={link.name}
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="flex items-center px-2 py-1 text-lg hover:text-blue-900"
                  >
                    {link.icon}
                    {link.name}
                  </Link>
                ))}
              </div>
            </SheetContent>
          </Sheet>
        ) : (
          <div className="flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className="flex items-center text-sm font-medium hover:text-blue-900"
              >
                {link.icon}
                {link.name}
              </Link>
            ))}
          </div>
        )}
      </div>
    </nav>
  )
}

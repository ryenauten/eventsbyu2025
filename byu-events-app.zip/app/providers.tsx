"use client"

import type { ReactNode } from "react"

import { CalendarProvider } from "@/hooks/use-calendar"

export function Providers({ children }: { children: ReactNode }) {
  return <CalendarProvider>{children}</CalendarProvider>
}

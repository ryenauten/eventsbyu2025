"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface CalendarContextType {
  savedEvents: string[]
  saveEvent: (eventId: string) => void
  removeEvent: (eventId: string) => void
}

const CalendarContext = createContext<CalendarContextType | undefined>(undefined)

export function CalendarProvider({ children }: { children: ReactNode }) {
  const [savedEvents, setSavedEvents] = useState<string[]>([])

  // Load saved events from localStorage on mount
  useEffect(() => {
    const storedEvents = localStorage.getItem("savedEvents")
    if (storedEvents) {
      setSavedEvents(JSON.parse(storedEvents))
    }
  }, [])

  // Save events to localStorage when they change
  useEffect(() => {
    localStorage.setItem("savedEvents", JSON.stringify(savedEvents))
  }, [savedEvents])

  const saveEvent = (eventId: string) => {
    setSavedEvents((prev) => {
      if (prev.includes(eventId)) return prev
      return [...prev, eventId]
    })
  }

  const removeEvent = (eventId: string) => {
    setSavedEvents((prev) => prev.filter((id) => id !== eventId))
  }

  return <CalendarContext.Provider value={{ savedEvents, saveEvent, removeEvent }}>{children}</CalendarContext.Provider>
}

export function useCalendar() {
  const context = useContext(CalendarContext)
  if (context === undefined) {
    throw new Error("useCalendar must be used within a CalendarProvider")
  }
  return context
}

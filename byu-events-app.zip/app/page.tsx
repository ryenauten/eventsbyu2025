import Link from "next/link"
import { Calendar, GraduationCap, Landmark, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { EventCategoryCard } from "@/components/event-category-card"

export default function HomePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-blue-900 md:text-4xl">Welcome to BYU Events!</h1>
        <p className="mt-2 text-gray-600">Discover and save campus events all in one place</p>
      </header>

      <div className="mb-8">
        <div className="relative">
          <Input type="search" placeholder="Search events by name or date..." className="pl-10 pr-4 py-2" />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-search"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.3-4.3" />
            </svg>
          </span>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <EventCategoryCard
          title="Sports Events"
          description="Games, matches, and athletic activities"
          icon={<Landmark className="h-8 w-8 text-blue-700" />}
          href="/events/sports"
          color="bg-blue-50"
        />

        <EventCategoryCard
          title="Underclassman Events"
          description="Activities for freshmen and sophomores"
          icon={<Users className="h-8 w-8 text-green-700" />}
          href="/events/underclassman"
          color="bg-green-50"
        />

        <EventCategoryCard
          title="Senior Events"
          description="Activities for juniors and seniors"
          icon={<GraduationCap className="h-8 w-8 text-purple-700" />}
          href="/events/senior"
          color="bg-purple-50"
        />

        <EventCategoryCard
          title="Club Events"
          description="Activities hosted by campus clubs"
          icon={<Users className="h-8 w-8 text-orange-700" />}
          href="/events/club"
          color="bg-orange-50"
        />
      </div>

      <div className="mt-8 text-center">
        <Link href="/calendar">
          <Button className="bg-blue-900 hover:bg-blue-800">
            <Calendar className="mr-2 h-4 w-4" />
            My Calendar
          </Button>
        </Link>
      </div>
    </div>
  )
}

import Link from "next/link"
import { Calendar, GraduationCap, Landmark, Users, TrendingUp, Bell } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { EventCategoryCard } from "@/components/event-category-card"
import { FeaturedEventsList } from "@/components/featured-events-list"

export default function HomePage() {
  return (
    <div className="container mx-auto px-4 py-6">
      <header className="mb-6 text-center">
        <div className="inline-block px-6 py-3 mb-4 bg-byu-navy text-white rounded-lg">
          <h1 className="text-2xl font-bold">BYU</h1>
        </div>
        <h1 className="text-3xl font-bold text-byu-navy md:text-4xl">Welcome to BYU Events!</h1>
        <p className="mt-2 text-gray-600">Discover and save campus events all in one place</p>
      </header>

      <div className="mb-6">
        <div className="relative">
          <Input
            type="search"
            placeholder="Search events by name or date..."
            className="pl-10 pr-4 py-2 border-byu-navy/30"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-search"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.3-4.3" />
            </svg>
          </span>
        </div>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-byu-navy">Upcoming Events</h2>
          <Link href="/calendar" className="text-byu-royal hover:underline text-sm font-medium">
            View All Events →
          </Link>
        </div>
        <FeaturedEventsList />
      </div>

      <div className="mb-8">
        <h2 className="text-2xl font-bold text-byu-navy mb-4">Event Categories</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <EventCategoryCard
            title="Sports Events"
            description="Games, matches, and athletic activities"
            icon={<Landmark className="h-8 w-8" />}
            href="/events/sports"
          />

          <EventCategoryCard
            title="Underclassman Events"
            description="Activities for freshmen and sophomores"
            icon={<Users className="h-8 w-8" />}
            href="/events/underclassman"
          />

          <EventCategoryCard
            title="Senior Events"
            description="Activities for juniors and seniors"
            icon={<GraduationCap className="h-8 w-8" />}
            href="/events/senior"
          />

          <EventCategoryCard
            title="Club Events"
            description="Activities hosted by campus clubs"
            icon={<Users className="h-8 w-8" />}
            href="/events/club"
          />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 mb-8">
        <div className="bg-byu-navy/5 rounded-lg p-6 border-t-4 border-byu-royal">
          <div className="flex items-center mb-4">
            <TrendingUp className="h-6 w-6 text-byu-royal mr-2" />
            <h2 className="text-xl font-bold text-byu-navy">Popular This Week</h2>
          </div>
          <ul className="space-y-3">
            <li className="p-3 bg-white rounded border border-gray-200 hover:border-byu-royal transition-colors">
              <Link href="/events/detail/9" className="block">
                <h3 className="font-medium text-byu-navy">BYU Football vs Boise State</h3>
                <p className="text-sm text-gray-600">LaVell Edwards Stadium • Nov 25</p>
              </Link>
            </li>
            <li className="p-3 bg-white rounded border border-gray-200 hover:border-byu-royal transition-colors">
              <Link href="/events/detail/8" className="block">
                <h3 className="font-medium text-byu-navy">International Club Cultural Night</h3>
                <p className="text-sm text-gray-600">Wilkinson Student Center • Nov 17</p>
              </Link>
            </li>
            <li className="p-3 bg-white rounded border border-gray-200 hover:border-byu-royal transition-colors">
              <Link href="/events/detail/3" className="block">
                <h3 className="font-medium text-byu-navy">Senior Career Fair</h3>
                <p className="text-sm text-gray-600">Marriott School of Business • Nov 20</p>
              </Link>
            </li>
          </ul>
        </div>

        <div className="bg-byu-navy/5 rounded-lg p-6 border-t-4 border-byu-royal">
          <div className="flex items-center mb-4">
            <Bell className="h-6 w-6 text-byu-royal mr-2" />
            <h2 className="text-xl font-bold text-byu-navy">Announcements</h2>
          </div>
          <ul className="space-y-3">
            <li className="p-3 bg-white rounded border border-gray-200">
              <h3 className="font-medium text-byu-navy">Winter Semester Registration</h3>
              <p className="text-sm text-gray-600">
                Registration for Winter Semester opens next week. Check your time slot!
              </p>
            </li>
            <li className="p-3 bg-white rounded border border-gray-200">
              <h3 className="font-medium text-byu-navy">Library Extended Hours</h3>
              <p className="text-sm text-gray-600">
                The Harold B. Lee Library will have extended hours during finals week.
              </p>
            </li>
            <li className="p-3 bg-white rounded border border-gray-200">
              <h3 className="font-medium text-byu-navy">Campus Closure Notice</h3>
              <p className="text-sm text-gray-600">Campus will be closed for Thanksgiving holiday from Nov 23-26.</p>
            </li>
          </ul>
        </div>
      </div>

      <div className="flex justify-center gap-4">
        <Link href="/calendar">
          <Button className="bg-byu-navy hover:bg-byu-royal">
            <Calendar className="mr-2 h-4 w-4" />
            My Calendar
          </Button>
        </Link>
        <Link href="/clubs">
          <Button variant="outline" className="border-byu-navy text-byu-navy hover:bg-byu-navy/10">
            <Users className="mr-2 h-4 w-4" />
            Browse Clubs
          </Button>
        </Link>
      </div>
    </div>
  )
}

"use client"

import { useEffect, useState } from "react"
import { CalendarIcon, ListFilter, CalendarIcon as CalendarView } from "lucide-react"
import Link from "next/link"

import { useCalendar } from "@/hooks/use-calendar"
import { type Event, getEventById } from "@/lib/data"
import { EventList } from "@/components/event-list"
import { Button } from "@/components/ui/button"
import { CalendarDisplay } from "@/components/calendar-display"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CalendarPage() {
  const { savedEvents } = useCalendar()
  const [events, setEvents] = useState<Event[]>([])

  useEffect(() => {
    // Get all saved events
    const eventsList = savedEvents.map((id) => getEventById(id)).filter((event): event is Event => event !== undefined)

    // Sort by date
    eventsList.sort((a, b) => new Date(a.startDateTime).getTime() - new Date(b.startDateTime).getTime())

    setEvents(eventsList)
  }, [savedEvents])

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-byu-navy">My Calendar</h1>
          <p className="text-gray-600">View and manage your saved events</p>
        </div>
        <div className="flex items-center gap-2 rounded-lg bg-byu-navy/10 px-4 py-2 text-byu-navy">
          <CalendarIcon className="h-5 w-5" />
          <span className="font-medium">{events.length} Saved Events</span>
        </div>
      </div>

      <Tabs defaultValue="list" className="mb-8">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="list" className="flex items-center gap-2">
            <ListFilter className="h-4 w-4" />
            List View
          </TabsTrigger>
          <TabsTrigger value="calendar" className="flex items-center gap-2">
            <CalendarView className="h-4 w-4" />
            Calendar View
          </TabsTrigger>
        </TabsList>

        <TabsContent value="list">
          {events.length === 0 ? (
            <div className="my-8 rounded-lg border border-dashed border-gray-300 bg-gray-50 p-8 text-center">
              <CalendarIcon className="mx-auto h-12 w-12 text-byu-royal/50" />
              <h2 className="mt-4 text-xl font-medium text-byu-navy">No saved events</h2>
              <p className="mt-2 text-gray-600 mb-4">Browse events and add them to your calendar to see them here.</p>
              <Link href="/">
                <Button className="bg-byu-navy hover:bg-byu-royal">Browse Events</Button>
              </Link>
            </div>
          ) : (
            <EventList events={events} />
          )}
        </TabsContent>

        <TabsContent value="calendar">
          <CalendarDisplay events={events} />
        </TabsContent>
      </Tabs>

      <div className="mt-8 p-6 bg-byu-navy/5 rounded-lg border-t-4 border-byu-royal">
        <h2 className="text-xl font-bold text-byu-navy mb-4">Upcoming Campus Events</h2>
        <p className="text-gray-600 mb-4">
          Explore all upcoming events on campus and add them to your personal calendar.
        </p>
        <div className="flex gap-4">
          <Link href="/events/sports">
            <Button variant="outline" className="border-byu-blue text-byu-blue hover:bg-byu-blue/10">
              Sports Events
            </Button>
          </Link>
          <Link href="/events/club">
            <Button variant="outline" className="border-byu-blue text-byu-blue hover:bg-byu-blue/10">
              Club Events
            </Button>
          </Link>
          <Link href="/">
            <Button variant="outline" className="border-byu-blue text-byu-blue hover:bg-byu-blue/10">
              All Events
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

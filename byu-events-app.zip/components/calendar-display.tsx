"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"
import type { Event } from "@/lib/data"
import { Button } from "@/components/ui/button"

interface CalendarDisplayProps {
  events: Event[]
}

export function CalendarDisplay({ events }: CalendarDisplayProps) {
  const [currentDate, setCurrentDate] = useState(new Date())

  // Get current month and year
  const currentMonth = currentDate.getMonth()
  const currentYear = currentDate.getFullYear()

  // Get first day of the month
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1)
  const startingDayOfWeek = firstDayOfMonth.getDay() // 0 = Sunday, 1 = Monday, etc.

  // Get number of days in the month
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate()

  // Get month name
  const monthName = currentDate.toLocaleString("default", { month: "long" })

  // Previous and next month handlers
  const goToPreviousMonth = () => {
    setCurrentDate(new Date(currentYear, currentMonth - 1, 1))
  }

  const goToNextMonth = () => {
    setCurrentDate(new Date(currentYear, currentMonth + 1, 1))
  }

  // Create calendar days array
  const calendarDays = []

  // Add empty cells for days before the first day of the month
  for (let i = 0; i < startingDayOfWeek; i++) {
    calendarDays.push(null)
  }

  // Add days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    calendarDays.push(day)
  }

  // Get events for the current month
  const eventsInMonth = events.filter((event) => {
    const eventDate = new Date(event.startDateTime)
    return eventDate.getMonth() === currentMonth && eventDate.getFullYear() === currentYear
  })

  // Create a map of day -> events for quick lookup
  const eventsByDay = eventsInMonth.reduce(
    (acc, event) => {
      const day = new Date(event.startDateTime).getDate()
      if (!acc[day]) {
        acc[day] = []
      }
      acc[day].push(event)
      return acc
    },
    {} as Record<number, Event[]>,
  )

  // Days of the week
  const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  return (
    <div className="bg-white rounded-lg border border-gray-200">
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <Button variant="ghost" size="sm" onClick={goToPreviousMonth}>
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h2 className="text-xl font-bold text-byu-navy">
          {monthName} {currentYear}
        </h2>
        <Button variant="ghost" size="sm" onClick={goToNextMonth}>
          <ChevronRight className="h-5 w-5" />
        </Button>
      </div>

      <div className="grid grid-cols-7">
        {/* Days of the week header */}
        {daysOfWeek.map((day) => (
          <div key={day} className="p-2 text-center font-medium text-sm border-b border-gray-200">
            {day}
          </div>
        ))}

        {/* Calendar days */}
        {calendarDays.map((day, index) => (
          <div
            key={index}
            className={`min-h-[100px] p-2 border-b border-r border-gray-200 ${day === null ? "bg-gray-50" : ""} ${
              day === new Date().getDate() &&
              currentMonth === new Date().getMonth() &&
              currentYear === new Date().getFullYear()
                ? "bg-byu-navy/5"
                : ""
            }`}
          >
            {day !== null && (
              <>
                <div className="font-medium text-sm mb-1">{day}</div>
                {eventsByDay[day]?.map((event) => (
                  <Link
                    key={event.id}
                    href={`/events/detail/${event.id}`}
                    className="block p-1 mb-1 text-xs rounded bg-byu-royal text-white truncate"
                    title={event.title}
                  >
                    {event.title}
                  </Link>
                ))}
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

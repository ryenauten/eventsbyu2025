import Link from "next/link"
import { CalendarIcon, Clock, MapPin } from "lucide-react"

import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Event } from "@/lib/data"
import { formatDate, formatTime } from "@/lib/utils"

interface EventCardProps {
  event: Event
}

export function EventCard({ event }: EventCardProps) {
  return (
    <Card className="overflow-hidden border-t-4 border-byu-royal">
      <CardHeader className="pb-2 bg-byu-navy/5">
        <h3 className="line-clamp-1 text-xl font-bold text-byu-navy">{event.title}</h3>
      </CardHeader>
      <CardContent className="space-y-2 pt-4 pb-2">
        <div className="flex items-start gap-2">
          <CalendarIcon className="mt-0.5 h-4 w-4 shrink-0 text-byu-royal" />
          <span className="text-sm">{formatDate(event.startDateTime)}</span>
        </div>
        <div className="flex items-start gap-2">
          <Clock className="mt-0.5 h-4 w-4 shrink-0 text-byu-royal" />
          <span className="text-sm">
            {formatTime(event.startDateTime)} - {formatTime(event.endDateTime)}
          </span>
        </div>
        <div className="flex items-start gap-2">
          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-byu-royal" />
          <span className="text-sm">{event.location}</span>
        </div>
        <p className="line-clamp-2 text-sm text-gray-600">{event.description}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/events/detail/${event.id}`} className="w-full">
          <Button variant="outline" className="w-full border-byu-blue text-byu-blue hover:bg-byu-blue/10">
            View Details
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}

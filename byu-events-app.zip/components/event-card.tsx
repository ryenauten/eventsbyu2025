import Link from "next/link"
import Image from "next/image"
import { CalendarIcon, Clock, MapPin } from "lucide-react"

import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Event } from "@/lib/data"
import { formatDate, formatTime } from "@/lib/utils"

interface EventCardProps {
  event: Event
}

export function EventCard({ event }: EventCardProps) {
  return (
    <Card className="overflow-hidden">
      <div className="relative h-48 w-full">
        <Image
          src={event.imageUrl || "/placeholder.svg?height=300&width=500"}
          alt={event.title}
          fill
          className="object-cover"
        />
      </div>
      <CardHeader className="pb-2">
        <h3 className="line-clamp-1 text-xl font-bold">{event.title}</h3>
      </CardHeader>
      <CardContent className="space-y-2 pb-2">
        <div className="flex items-start gap-2">
          <CalendarIcon className="mt-0.5 h-4 w-4 shrink-0 text-gray-500" />
          <span className="text-sm">{formatDate(event.startDateTime)}</span>
        </div>
        <div className="flex items-start gap-2">
          <Clock className="mt-0.5 h-4 w-4 shrink-0 text-gray-500" />
          <span className="text-sm">
            {formatTime(event.startDateTime)} - {formatTime(event.endDateTime)}
          </span>
        </div>
        <div className="flex items-start gap-2">
          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gray-500" />
          <span className="text-sm">{event.location}</span>
        </div>
        <p className="line-clamp-2 text-sm text-gray-600">{event.description}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/events/detail/${event.id}`} className="w-full">
          <Button variant="outline" className="w-full">
            View Details
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}

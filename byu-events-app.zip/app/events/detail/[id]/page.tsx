import { notFound } from "next/navigation"
import { CalendarIcon, Clock, MapPin } from "lucide-react"
import type { Metadata } from "next"

import { getEventById } from "@/lib/data"
import { formatDate, formatTime } from "@/lib/utils"
import { SaveEventButton } from "@/components/save-event-button"

export const metadata: Metadata = {
  title: "Event Details | BYU Campus Events",
  description: "View event details and add to your calendar",
}

export default function EventDetailPage({ params }: { params: { id: string } }) {
  const event = getEventById(params.id)

  if (!event) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 overflow-hidden rounded-xl bg-byu-navy/5 p-8 border-t-4 border-byu-royal">
          <h1 className="text-3xl font-bold text-byu-navy md:text-4xl">{event.title}</h1>
          <p className="mt-4 text-gray-600 italic">
            {event.eventType.charAt(0).toUpperCase() + event.eventType.slice(1)} Event
          </p>
        </div>

        <div className="mb-8">
          <div className="mb-6 grid gap-4 md:grid-cols-3">
            <div className="flex items-start gap-2">
              <CalendarIcon className="mt-1 h-5 w-5 shrink-0 text-byu-royal" />
              <div>
                <p className="font-medium">Date</p>
                <p className="text-gray-600">{formatDate(event.startDateTime)}</p>
              </div>
            </div>

            <div className="flex items-start gap-2">
              <Clock className="mt-1 h-5 w-5 shrink-0 text-byu-royal" />
              <div>
                <p className="font-medium">Time</p>
                <p className="text-gray-600">
                  {formatTime(event.startDateTime)} - {formatTime(event.endDateTime)}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2">
              <MapPin className="mt-1 h-5 w-5 shrink-0 text-byu-royal" />
              <div>
                <p className="font-medium">Location</p>
                <p className="text-gray-600">{event.location}</p>
              </div>
            </div>
          </div>

          <div className="mb-8 p-6 bg-white rounded-lg border border-gray-200">
            <h2 className="mb-2 text-xl font-semibold text-byu-navy">Description</h2>
            <p className="text-gray-700">{event.description}</p>
          </div>

          <SaveEventButton eventId={event.id} />
        </div>
      </div>
    </div>
  )
}

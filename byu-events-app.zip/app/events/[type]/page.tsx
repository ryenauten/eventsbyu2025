import { notFound } from "next/navigation"
import type { Metadata } from "next"

import { EventList } from "@/components/event-list"
import { EventType, getEventsByType } from "@/lib/data"

export const metadata: Metadata = {
  title: "Events | BYU Campus Events",
  description: "Browse events by category",
}

export default function EventsPage({ params }: { params: { type: string } }) {
  // Validate the event type
  if (!Object.values(EventType).includes(params.type as EventType)) {
    notFound()
  }

  const eventType = params.type as EventType
  const events = getEventsByType(eventType)

  // Format the title for display
  const formatTitle = (type: string) => {
    return type.charAt(0).toUpperCase() + type.slice(1) + " Events"
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold text-blue-900">{formatTitle(eventType)}</h1>

      <EventList events={events} />
    </div>
  )
}

import Link from "next/link"
import type { ReactNode } from "react"

import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface EventCategoryCardProps {
  title: string
  description: string
  icon: ReactNode
  href: string
  color?: string
}

export function EventCategoryCard({ title, description, icon, href, color = "bg-gray-50" }: EventCategoryCardProps) {
  return (
    <Link href={href} className="block transition-transform hover:scale-105">
      <Card className={cn("h-full overflow-hidden", color)}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl">{title}</CardTitle>
            {icon}
          </div>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardFooter className="pb-4">
          <span className="text-sm font-medium text-blue-900">View Events →</span>
        </CardFooter>
      </Card>
    </Link>
  )
}

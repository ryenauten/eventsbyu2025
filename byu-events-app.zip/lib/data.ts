export enum EventType {
  Sports = "sports",
  Underclassman = "underclassman",
  Senior = "senior",
  Club = "club",
}

export interface Event {
  id: string
  title: string
  description: string
  startDateTime: string
  endDateTime: string
  location: string
  eventType: EventType
}

// Sample data for the app
export const events: Event[] = [
  // SPORTS EVENTS
  {
    id: "1",
    title: "BYU vs Utah Basketball Game",
    description: "Come support the Cougars as they take on the Utes in this rivalry basketball game!",
    startDateTime: "2023-11-15T19:00:00",
    endDateTime: "2023-11-15T21:30:00",
    location: "Marriott Center",
    eventType: EventType.Sports,
  },
  {
    id: "5",
    title: "Women's Volleyball Tournament",
    description: "Watch the BYU women's volleyball team compete in the regional tournament.",
    startDateTime: "2023-11-18T14:00:00",
    endDateTime: "2023-11-18T17:00:00",
    location: "Smith Fieldhouse",
    eventType: EventType.Sports,
  },
  {
    id: "9",
    title: "BYU Football vs Boise State",
    description: "Cheer on the Cougars as they face the Broncos in this exciting football matchup!",
    startDateTime: "2023-11-25T15:30:00",
    endDateTime: "2023-11-25T19:00:00",
    location: "LaVell Edwards Stadium",
    eventType: EventType.Sports,
  },
  {
    id: "13",
    title: "BYU Tennis Invitational",
    description: "Watch BYU's tennis team compete against top schools in this weekend tournament.",
    startDateTime: "2023-12-02T09:00:00",
    endDateTime: "2023-12-03T17:00:00",
    location: "BYU Tennis Courts",
    eventType: EventType.Sports,
  },
  {
    id: "17",
    title: "Swimming & Diving Competition",
    description: "BYU's swimming and diving teams compete in this exciting home meet.",
    startDateTime: "2023-12-08T13:00:00",
    endDateTime: "2023-12-08T17:00:00",
    location: "Richards Building Pool",
    eventType: EventType.Sports,
  },

  // UNDERCLASSMAN EVENTS
  {
    id: "2",
    title: "Freshman Orientation Social",
    description: "Meet other freshmen and get to know campus resources in this fun social event.",
    startDateTime: "2023-11-10T16:00:00",
    endDateTime: "2023-11-10T18:00:00",
    location: "Wilkinson Student Center",
    eventType: EventType.Underclassman,
  },
  {
    id: "6",
    title: "Sophomore Study Skills Workshop",
    description: "Learn effective study techniques to improve your academic performance.",
    startDateTime: "2023-11-12T13:00:00",
    endDateTime: "2023-11-12T15:00:00",
    location: "Harold B. Lee Library",
    eventType: EventType.Underclassman,
  },
  {
    id: "10",
    title: "Freshman Dorm Game Night",
    description: "Join other freshmen for a fun night of board games, snacks, and making new friends!",
    startDateTime: "2023-11-17T19:00:00",
    endDateTime: "2023-11-17T22:00:00",
    location: "Helaman Halls",
    eventType: EventType.Underclassman,
  },
  {
    id: "14",
    title: "Sophomore Major Fair",
    description: "Explore different majors and talk to department representatives about your academic options.",
    startDateTime: "2023-11-28T11:00:00",
    endDateTime: "2023-11-28T14:00:00",
    location: "Wilkinson Student Center Ballroom",
    eventType: EventType.Underclassman,
  },
  {
    id: "18",
    title: "Freshman Winter Social",
    description: "Celebrate the end of your first semester with hot chocolate, games, and new friends!",
    startDateTime: "2023-12-09T18:00:00",
    endDateTime: "2023-12-09T21:00:00",
    location: "Cannon Center",
    eventType: EventType.Underclassman,
  },

  // SENIOR EVENTS
  {
    id: "3",
    title: "Senior Career Fair",
    description: "Connect with potential employers and explore career opportunities after graduation.",
    startDateTime: "2023-11-20T10:00:00",
    endDateTime: "2023-11-20T15:00:00",
    location: "Marriott School of Business",
    eventType: EventType.Senior,
  },
  {
    id: "7",
    title: "Senior Graduation Photo Session",
    description: "Professional graduation photos for seniors graduating this year.",
    startDateTime: "2023-11-22T09:00:00",
    endDateTime: "2023-11-22T17:00:00",
    location: "Brimhall Building",
    eventType: EventType.Senior,
  },
  {
    id: "11",
    title: "Graduate School Application Workshop",
    description: "Get tips and advice on applying to graduate programs from admissions experts.",
    startDateTime: "2023-11-30T15:00:00",
    endDateTime: "2023-11-30T17:00:00",
    location: "Jesse Knight Building",
    eventType: EventType.Senior,
  },
  {
    id: "15",
    title: "Senior Networking Dinner",
    description: "Connect with alumni and industry professionals in your field at this formal networking dinner.",
    startDateTime: "2023-12-05T18:00:00",
    endDateTime: "2023-12-05T21:00:00",
    location: "Hinckley Alumni Center",
    eventType: EventType.Senior,
  },
  {
    id: "19",
    title: "Graduation Cap Decorating Party",
    description: "Get creative and decorate your graduation cap with fellow seniors!",
    startDateTime: "2023-12-10T14:00:00",
    endDateTime: "2023-12-10T16:00:00",
    location: "Wilkinson Student Center",
    eventType: EventType.Senior,
  },

  // CLUB EVENTS
  {
    id: "4",
    title: "Computer Science Club Hackathon",
    description: "Join the CS Club for a 24-hour coding competition with prizes and food!",
    startDateTime: "2023-11-25T18:00:00",
    endDateTime: "2023-11-26T18:00:00",
    location: "Talmage Building",
    eventType: EventType.Club,
  },
  {
    id: "8",
    title: "International Club Cultural Night",
    description: "Experience cultures from around the world through food, performances, and activities.",
    startDateTime: "2023-11-17T18:00:00",
    endDateTime: "2023-11-17T21:00:00",
    location: "Wilkinson Student Center Ballroom",
    eventType: EventType.Club,
  },
  {
    id: "12",
    title: "Business Club Speaker Series",
    description: "Hear from successful entrepreneurs and business leaders about their career journeys.",
    startDateTime: "2023-12-01T19:00:00",
    endDateTime: "2023-12-01T21:00:00",
    location: "Tanner Building Auditorium",
    eventType: EventType.Club,
  },
  {
    id: "16",
    title: "Art Club Exhibition",
    description: "View artwork created by BYU students and participate in interactive art activities.",
    startDateTime: "2023-12-07T17:00:00",
    endDateTime: "2023-12-07T20:00:00",
    location: "HFAC Gallery",
    eventType: EventType.Club,
  },
  {
    id: "20",
    title: "Outdoor Adventure Club Hike",
    description: "Join the Outdoor Adventure Club for a guided hike in the beautiful mountains near campus.",
    startDateTime: "2023-12-11T09:00:00",
    endDateTime: "2023-12-11T14:00:00",
    location: "Meet at Wilkinson Student Center",
    eventType: EventType.Club,
  },
]

// Helper function to get events by type
export function getEventsByType(type: EventType): Event[] {
  return events.filter((event) => event.eventType === type)
}

// Helper function to get event by ID
export function getEventById(id: string): Event | undefined {
  return events.find((event) => event.id === id)
}

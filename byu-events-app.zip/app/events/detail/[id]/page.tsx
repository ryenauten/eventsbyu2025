import { notFound } from "next/navigation"
import Image from "next/image"
import { CalendarIcon, Clock, MapPin } from "lucide-react"
import type { Metadata } from "next"

import { getEventById } from "@/lib/data"
import { formatDate, formatTime } from "@/lib/utils"
import { SaveEventButton } from "@/components/save-event-button"

export const metadata: Metadata = {
  title: "Event Details | BYU Campus Events",
  description: "View event details and add to your calendar",
}

export default function EventDetailPage({ params }: { params: { id: string } }) {
  const event = getEventById(params.id)

  if (!event) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 overflow-hidden rounded-xl">
          <div className="relative h-64 w-full sm:h-80 md:h-96">
            <Image
              src={event.imageUrl || "/placeholder.svg?height=600&width=1200"}
              alt={event.title}
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>

        <div className="mb-8">
          <h1 className="mb-4 text-3xl font-bold text-blue-900 md:text-4xl">{event.title}</h1>

          <div className="mb-6 grid gap-4 md:grid-cols-3">
            <div className="flex items-start gap-2">
              <CalendarIcon className="mt-1 h-5 w-5 shrink-0 text-blue-900" />
              <div>
                <p className="font-medium">Date</p>
                <p className="text-gray-600">{formatDate(event.startDateTime)}</p>
              </div>
            </div>

            <div className="flex items-start gap-2">
              <Clock className="mt-1 h-5 w-5 shrink-0 text-blue-900" />
              <div>
                <p className="font-medium">Time</p>
                <p className="text-gray-600">
                  {formatTime(event.startDateTime)} - {formatTime(event.endDateTime)}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2">
              <MapPin className="mt-1 h-5 w-5 shrink-0 text-blue-900" />
              <div>
                <p className="font-medium">Location</p>
                <p className="text-gray-600">{event.location}</p>
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="mb-2 text-xl font-semibold">Description</h2>
            <p className="text-gray-700">{event.description}</p>
          </div>

          <SaveEventButton eventId={event.id} />
        </div>
      </div>
    </div>
  )
}

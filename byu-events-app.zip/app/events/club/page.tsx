import Link from "next/link"
import { Users } from "lucide-react"
import type { Metadata } from "next"

import { EventList } from "@/components/event-list"
import { EventType, getEventsByType } from "@/lib/data"
import { Button } from "@/components/ui/button"

export const metadata: Metadata = {
  title: "Club Events | BYU Campus Events",
  description: "Browse club events at BYU",
}

export default function ClubEventsPage() {
  const events = getEventsByType(EventType.Club)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-byu-navy mb-6">Club Events</h1>

      <div className="bg-byu-navy/10 p-6 rounded-lg mb-8 border-t-4 border-byu-royal">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-byu-navy mb-2">BYU Clubs Directory</h2>
            <p className="text-gray-700 mb-4 md:mb-0">
              BYU has over 100 student clubs and organizations. Find one that matches your interests!
            </p>
          </div>
          <Link href="/clubs">
            <Button className="bg-byu-navy hover:bg-byu-royal">
              <Users className="mr-2 h-4 w-4" />
              Browse All Clubs
            </Button>
          </Link>
        </div>
      </div>

      <h2 className="text-2xl font-bold text-byu-navy mb-4">Upcoming Club Events</h2>
      <EventList events={events} />
    </div>
  )
}

"use client"

import { useEffect, useState } from "react"
import { CalendarIcon } from "lucide-react"

import { useCalendar } from "@/hooks/use-calendar"
import { type Event, getEventById } from "@/lib/data"
import { EventList } from "@/components/event-list"

export default function CalendarPage() {
  const { savedEvents } = useCalendar()
  const [events, setEvents] = useState<Event[]>([])

  useEffect(() => {
    // Get all saved events
    const eventsList = savedEvents.map((id) => getEventById(id)).filter((event): event is Event => event !== undefined)

    // Sort by date
    eventsList.sort((a, b) => new Date(a.startDateTime).getTime() - new Date(b.startDateTime).getTime())

    setEvents(eventsList)
  }, [savedEvents])

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex items-center justify-between">
        <h1 className="text-3xl font-bold text-blue-900">My Calendar</h1>
        <div className="flex items-center gap-2 rounded-lg bg-blue-50 px-4 py-2 text-blue-900">
          <CalendarIcon className="h-5 w-5" />
          <span className="font-medium">{events.length} Saved Events</span>
        </div>
      </div>

      {events.length === 0 ? (
        <div className="my-12 rounded-lg border border-dashed border-gray-300 bg-gray-50 p-8 text-center">
          <CalendarIcon className="mx-auto h-12 w-12 text-gray-400" />
          <h2 className="mt-4 text-xl font-medium text-gray-900">No saved events</h2>
          <p className="mt-2 text-gray-600">Browse events and add them to your calendar to see them here.</p>
        </div>
      ) : (
        <EventList events={events} />
      )}
    </div>
  )
}

import Link from "next/link"
import { ExternalLink, Users } from "lucide-react"
import type { Metadata } from "next"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export const metadata: Metadata = {
  title: "BYU Clubs | BYU Campus Events",
  description: "Browse all clubs at BYU",
}

// Sample club data
const clubs = [
  {
    id: "1",
    name: "Computer Science Club",
    description: "For students interested in computer science, programming, and technology.",
    memberCount: 120,
    website: "https://example.com/cs-club",
  },
  {
    id: "2",
    name: "International Student Association",
    description: "Bringing together international students and promoting cultural exchange.",
    memberCount: 85,
    website: "https://example.com/isa",
  },
  {
    id: "3",
    name: "Business Strategy Club",
    description: "Developing business acumen through case competitions and networking events.",
    memberCount: 95,
    website: "https://example.com/business-club",
  },
  {
    id: "4",
    name: "Outdoor Adventure Club",
    description: "Exploring Utah's natural beauty through hiking, climbing, and camping trips.",
    memberCount: 150,
    website: "https://example.com/outdoor-club",
  },
  {
    id: "5",
    name: "Film Society",
    description: "Watching and discussing films from various genres and cultures.",
    memberCount: 65,
    website: "https://example.com/film-society",
  },
  {
    id: "6",
    name: "Ballroom Dance Club",
    description: "Learning and performing various ballroom dance styles.",
    memberCount: 70,
    website: "https://example.com/ballroom-dance",
  },
  {
    id: "7",
    name: "Pre-Med Association",
    description: "Supporting students on their journey to medical school.",
    memberCount: 110,
    website: "https://example.com/pre-med",
  },
  {
    id: "8",
    name: "Engineering Club",
    description: "Hands-on projects and competitions for engineering students.",
    memberCount: 130,
    website: "https://example.com/engineering-club",
  },
  {
    id: "9",
    name: "Chess Club",
    description: "Weekly chess matches and tournaments for players of all levels.",
    memberCount: 45,
    website: "https://example.com/chess-club",
  },
  {
    id: "10",
    name: "Acapella Club",
    description: "Vocal performance group focusing on acapella arrangements.",
    memberCount: 60,
    website: "https://example.com/acapella-club",
  },
  {
    id: "11",
    name: "Psychology Club",
    description: "Exploring the human mind through discussions and guest speakers.",
    memberCount: 75,
    website: "https://example.com/psychology-club",
  },
  {
    id: "12",
    name: "Art Club",
    description: "Creating and appreciating various forms of visual art.",
    memberCount: 55,
    website: "https://example.com/art-club",
  },
]

// Club categories for filtering
const categories = [
  "All Clubs",
  "Academic",
  "Cultural",
  "Professional",
  "Recreational",
  "Service",
  "Sports",
  "Religious",
]

export default function ClubsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-byu-navy mb-2">BYU Clubs</h1>
      <p className="text-gray-600 mb-6">Browse and discover student clubs and organizations at BYU</p>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-grow">
          <Input
            type="search"
            placeholder="Search clubs by name or keyword..."
            className="pl-10 pr-4 py-2 border-byu-navy/30 w-full"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-search"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.3-4.3" />
            </svg>
          </span>
        </div>
        <select className="border border-gray-300 rounded-md px-3 py-2 bg-white md:w-48">
          <option value="">Filter by Category</option>
          {categories.map((category) => (
            <option key={category} value={category.toLowerCase()}>
              {category}
            </option>
          ))}
        </select>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {clubs.map((club) => (
          <div
            key={club.id}
            className="border border-gray-200 rounded-lg overflow-hidden hover:border-byu-royal transition-colors"
          >
            <div className="bg-byu-navy/5 p-4 border-b border-gray-200">
              <h3 className="font-bold text-byu-navy text-lg">{club.name}</h3>
            </div>
            <div className="p-4">
              <p className="text-gray-600 mb-4">{club.description}</p>
              <div className="flex items-center text-sm text-gray-500 mb-4">
                <Users className="h-4 w-4 mr-1" />
                <span>{club.memberCount} members</span>
              </div>
              <div className="flex justify-between items-center">
                <Link href={`/clubs/${club.id}`}>
                  <Button variant="outline" size="sm" className="text-byu-blue border-byu-blue hover:bg-byu-blue/10">
                    View Club
                  </Button>
                </Link>
                <a
                  href={club.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-byu-royal hover:underline text-sm flex items-center"
                >
                  Website <ExternalLink className="h-3 w-3 ml-1" />
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 text-center">
        <p className="text-gray-600 mb-4">Don't see your club? Register it on the BYU Clubs platform.</p>
        <Button className="bg-byu-navy hover:bg-byu-royal">Register a New Club</Button>
      </div>
    </div>
  )
}

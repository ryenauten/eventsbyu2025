import Link from "next/link"
import { CalendarIcon } from "lucide-react"

import { events } from "@/lib/data"
import { formatDate } from "@/lib/utils"

export function FeaturedEventsList() {
  // Get upcoming events (next 5 events by date)
  const upcomingEvents = [...events]
    .sort((a, b) => new Date(a.startDateTime).getTime() - new Date(b.startDateTime).getTime())
    .filter((event) => new Date(event.startDateTime) >= new Date())
    .slice(0, 5)

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {upcomingEvents.map((event) => (
        <Link
          key={event.id}
          href={`/events/detail/${event.id}`}
          className="block p-4 bg-white rounded-lg border border-gray-200 hover:border-byu-royal transition-colors"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium px-2 py-0.5 rounded bg-byu-navy/10 text-byu-navy">
              {event.eventType.charAt(0).toUpperCase() + event.eventType.slice(1)}
            </span>
            <span className="flex items-center text-sm text-gray-500">
              <CalendarIcon className="h-3 w-3 mr-1" />
              {formatDate(event.startDateTime)}
            </span>
          </div>
          <h3 className="font-bold text-byu-navy mb-1">{event.title}</h3>
          <p className="text-sm text-gray-600 line-clamp-2">{event.description}</p>
        </Link>
      ))}
    </div>
  )
}
